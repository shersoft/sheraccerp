// @dart = 2.11
class Shop {
  String shop;
  String shopid;

  Shop({this.shop, this.shopid});
}
